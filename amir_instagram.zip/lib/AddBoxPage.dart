import 'package:flutter/material.dart';

class AddBoxPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: new Text('AddBoxPage'),
    );
  }
}
