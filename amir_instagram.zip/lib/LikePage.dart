import 'package:flutter/material.dart';

class LikePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: new Text('LikePage'),
    );
  }
}
